#!/usr/bin/env python

class Instruction:
	def __init__(self, addr_mode, function):
		self.addr_mode = addr_mode
		self.function = function
