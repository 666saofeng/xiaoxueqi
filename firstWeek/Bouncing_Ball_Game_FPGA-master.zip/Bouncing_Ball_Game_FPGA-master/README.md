A simple game programmed by verilog. Further modification based on the existed source code can easily achieve the effect shown in the video.
